<script setup>
import { RouterView } from "vue-router";

</script>
 
<template>
  <div>
    <RouterView />
  </div>
</template>
 
<style scoped></style>